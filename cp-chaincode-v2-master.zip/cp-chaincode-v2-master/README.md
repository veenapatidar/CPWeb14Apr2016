# cp-chaincode-v2
Updated commercial paper chaincode.  Separated for backwards compatibility.  Go to cp-web for instructions: <https://github.com/IBM-Blockchain/cp-web>
